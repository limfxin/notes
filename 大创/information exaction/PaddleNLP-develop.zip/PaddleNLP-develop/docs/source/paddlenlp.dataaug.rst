paddlenlp.dataaug
=========================

.. automodule:: paddlenlp.dataaug
   :members:
   :no-undoc-members:
   :show-inheritance:


.. toctree::
   :maxdepth: 4

   paddlenlp.dataaug.base_augment
   paddlenlp.dataaug.word_delete
   paddlenlp.dataaug.word_insert
   paddlenlp.dataaug.word_substitute
   paddlenlp.dataaug.word_swap
