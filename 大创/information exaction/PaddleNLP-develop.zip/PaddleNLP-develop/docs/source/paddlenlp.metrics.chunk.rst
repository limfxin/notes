chunk
==============================

.. automodule:: paddlenlp.metrics.chunk
   :members:
   :no-undoc-members:
   :show-inheritance:
