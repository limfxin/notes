random
=============================================

.. automodule:: paddlenlp.ops.distributed.utils.random
   :members:
   :no-undoc-members:
