word\_insert
=====================================

.. automodule:: paddlenlp.dataaug.word_insert
   :members:
   :no-undoc-members:
   :show-inheritance:
