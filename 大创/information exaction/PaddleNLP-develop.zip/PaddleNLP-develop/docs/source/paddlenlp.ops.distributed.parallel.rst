parallel
=========================================

.. automodule:: paddlenlp.ops.distributed.parallel
   :members:
   :no-undoc-members:
