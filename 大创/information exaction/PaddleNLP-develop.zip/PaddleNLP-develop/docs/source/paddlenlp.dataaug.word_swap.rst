word\_swap
===================================

.. automodule:: paddlenlp.dataaug.word_swap
   :members:
   :no-undoc-members:
   :show-inheritance:
