rdrop
=============================

.. automodule:: paddlenlp.losses.rdrop
   :members:
   :no-undoc-members:
