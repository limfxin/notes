distributed
=================================

.. automodule:: paddlenlp.ops.distributed
   :members:
   :no-undoc-members:


.. toctree::
   :maxdepth: 4

   paddlenlp.ops.distributed.utils


.. toctree::
   :maxdepth: 4

   paddlenlp.ops.distributed.parallel
