einsum
===========================

.. automodule:: paddlenlp.ops.einsum
   :members:
   :no-undoc-members:
   :show-inheritance:
