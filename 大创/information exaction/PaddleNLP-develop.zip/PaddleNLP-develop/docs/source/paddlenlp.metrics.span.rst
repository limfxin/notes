span
=============================

.. automodule:: paddlenlp.metrics.span
   :members:
   :no-undoc-members:
   :show-inheritance:
