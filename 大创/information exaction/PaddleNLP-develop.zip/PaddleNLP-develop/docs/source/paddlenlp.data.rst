paddlenlp.data
======================

.. automodule:: paddlenlp.data
   :members:
   :no-undoc-members:
   :show-inheritance:


.. toctree::
   :maxdepth: 4

   paddlenlp.data.collate
   paddlenlp.data.data_collator
   paddlenlp.data.iterator
   paddlenlp.data.sampler
   paddlenlp.data.tokenizer
   paddlenlp.data.vocab
