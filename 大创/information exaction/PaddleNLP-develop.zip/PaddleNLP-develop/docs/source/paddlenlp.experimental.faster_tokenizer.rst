faster\_tokenizer
===============================================

.. automodule:: paddlenlp.experimental.faster_tokenizer
   :members:
   :no-undoc-members:
   :show-inheritance:
