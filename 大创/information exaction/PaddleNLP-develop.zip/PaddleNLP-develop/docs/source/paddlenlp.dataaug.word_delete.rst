word\_delete
=====================================

.. automodule:: paddlenlp.dataaug.word_delete
   :members:
   :no-undoc-members:
   :show-inheritance:
