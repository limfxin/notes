paddlenlp.experimental
==============================

.. automodule:: paddlenlp.experimental
   :members:
   :no-undoc-members:
   :show-inheritance:


.. toctree::
   :maxdepth: 4

   paddlenlp.experimental.ernie_model
   paddlenlp.experimental.faster_tokenizer
   paddlenlp.experimental.model_utils
