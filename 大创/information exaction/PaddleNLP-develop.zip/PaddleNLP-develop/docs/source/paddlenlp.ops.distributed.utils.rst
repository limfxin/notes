utils
=======================================

.. automodule:: paddlenlp.ops.distributed.utils
   :members:
   :no-undoc-members:


.. toctree::
   :maxdepth: 4

   paddlenlp.ops.distributed.utils.random
   paddlenlp.ops.distributed.utils.topo
