word\_substitute
=========================================

.. automodule:: paddlenlp.dataaug.word_substitute
   :members:
   :no-undoc-members:
   :show-inheritance:
