base\_augment
======================================

.. automodule:: paddlenlp.dataaug.base_augment
   :members:
   :no-undoc-members:
   :show-inheritance:
