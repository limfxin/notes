============
文本生成高性能加速
============

.. toctree::
   :maxdepth: 1

   fastertransformer.rst
