python export_model.py \
                       --params_path checkpoints/model_80000/model_state.pdparams \
                       --model_name_or_path rocketqa-base-cross-encoder \
                       --output_path=./output