python export_model.py --params_path checkpoints/model_30000/model_state.pdparams \
                       --output_path=./output \
                       --model_name_or_path ernie-3.0-medium-zh