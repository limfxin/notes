python deploy/python/predict.py --model_dir ./output \
                                --input_file sort/test_pairwise.csv \
                                --model_name_or_path ernie-3.0-medium-zh