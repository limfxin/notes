python export_model.py --params_path checkpoints/model_12000/model_state.pdparams \
                       --model_name_or_path rocketqa-zh-base-query-encoder \
                       --output_path=./output